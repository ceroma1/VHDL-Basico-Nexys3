/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Temp/alu/operaciones.vhd";
extern char *IEEE_P_0774719531;
extern char *IEEE_P_3499444699;

int ieee_p_0774719531_sub_378705076_2162500114(char *, char *, char *);
char *ieee_p_3499444699_sub_2213602152_3536714472(char *, char *, int , int );


static void work_a_1481485318_3212880686_p_0(char *t0)
{
    char t8[16];
    char *t1;
    char *t2;
    int t3;
    char *t4;
    char *t5;
    int t6;
    int t7;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(19, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4848U);
    t3 = ieee_p_0774719531_sub_378705076_2162500114(IEEE_P_0774719531, t2, t1);
    t4 = (t0 + 1648U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    *((int *)t4) = t3;
    xsi_set_current_line(20, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 4864U);
    t3 = ieee_p_0774719531_sub_378705076_2162500114(IEEE_P_0774719531, t2, t1);
    t4 = (t0 + 1768U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    *((int *)t4) = t3;
    xsi_set_current_line(21, ng0);
    t1 = (t0 + 1648U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    t1 = (t0 + 1768U);
    t4 = *((char **)t1);
    t6 = *((int *)t4);
    t7 = (t3 - t6);
    t1 = (t0 + 1888U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t7;
    xsi_set_current_line(22, ng0);
    t1 = (t0 + 1888U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    t1 = ieee_p_3499444699_sub_2213602152_3536714472(IEEE_P_3499444699, t8, t3, 5);
    t4 = (t8 + 12U);
    t9 = *((unsigned int *)t4);
    t9 = (t9 * 1U);
    t10 = (5U != t9);
    if (t10 == 1)
        goto LAB2;

LAB3:    t5 = (t0 + 3272);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 5U);
    xsi_driver_first_trans_fast_port(t5);
    t1 = (t0 + 3192);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_size_not_matching(5U, t9, 0);
    goto LAB3;

}


extern void work_a_1481485318_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1481485318_3212880686_p_0};
	xsi_register_didat("work_a_1481485318_3212880686", "isim/tes_isim_beh.exe.sim/work/a_1481485318_3212880686.didat");
	xsi_register_executes(pe);
}
