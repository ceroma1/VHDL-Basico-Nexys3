/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Temp/alu/operaciones.vhd";
extern char *IEEE_P_0774719531;
extern char *IEEE_P_3499444699;

unsigned char ieee_p_0774719531_sub_2698824431_2162500114(char *, char *, char *, char *, char *);
int ieee_p_0774719531_sub_378705076_2162500114(char *, char *, char *);
char *ieee_p_3499444699_sub_2213602152_3536714472(char *, char *, int , int );


static void work_a_1481485318_3212880686_p_0(char *t0)
{
    char t6[16];
    char *t1;
    char *t2;
    int t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    int t12;
    char *t13;
    int t14;
    int t15;
    char *t16;

LAB0:    xsi_set_current_line(20, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 5060U);
    t3 = ieee_p_0774719531_sub_378705076_2162500114(IEEE_P_0774719531, t2, t1);
    t4 = (t0 + 1808U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    *((int *)t4) = t3;
    xsi_set_current_line(21, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 5076U);
    t3 = ieee_p_0774719531_sub_378705076_2162500114(IEEE_P_0774719531, t2, t1);
    t4 = (t0 + 1928U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    *((int *)t4) = t3;
    xsi_set_current_line(22, ng0);
    t1 = (t0 + 2048U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;
    xsi_set_current_line(24, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 5092U);
    t4 = (t0 + 5156);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t3 = (1 - 0);
    t9 = (t3 * 1);
    t9 = (t9 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t9;
    t10 = ieee_p_0774719531_sub_2698824431_2162500114(IEEE_P_0774719531, t2, t1, t4, t6);
    if (t10 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 5092U);
    t4 = (t0 + 5158);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t3 = (1 - 0);
    t9 = (t3 * 1);
    t9 = (t9 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t9;
    t10 = ieee_p_0774719531_sub_2698824431_2162500114(IEEE_P_0774719531, t2, t1, t4, t6);
    if (t10 != 0)
        goto LAB5;

LAB6:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 5092U);
    t4 = (t0 + 5160);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t3 = (1 - 0);
    t9 = (t3 * 1);
    t9 = (t9 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t9;
    t10 = ieee_p_0774719531_sub_2698824431_2162500114(IEEE_P_0774719531, t2, t1, t4, t6);
    if (t10 != 0)
        goto LAB7;

LAB8:    xsi_set_current_line(31, ng0);
    t1 = (t0 + 2048U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;

LAB3:    xsi_set_current_line(33, ng0);
    t1 = (t0 + 2048U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    t1 = ieee_p_3499444699_sub_2213602152_3536714472(IEEE_P_3499444699, t6, t3, 8);
    t4 = (t6 + 12U);
    t9 = *((unsigned int *)t4);
    t9 = (t9 * 1U);
    t10 = (8U != t9);
    if (t10 == 1)
        goto LAB9;

LAB10:    t5 = (t0 + 3432);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    t11 = (t8 + 56U);
    t13 = *((char **)t11);
    memcpy(t13, t1, 8U);
    xsi_driver_first_trans_fast_port(t5);
    t1 = (t0 + 3352);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(25, ng0);
    t8 = (t0 + 1808U);
    t11 = *((char **)t8);
    t12 = *((int *)t11);
    t8 = (t0 + 1928U);
    t13 = *((char **)t8);
    t14 = *((int *)t13);
    t15 = (t12 + t14);
    t8 = (t0 + 2048U);
    t16 = *((char **)t8);
    t8 = (t16 + 0);
    *((int *)t8) = t15;
    goto LAB3;

LAB5:    xsi_set_current_line(27, ng0);
    t8 = (t0 + 1808U);
    t11 = *((char **)t8);
    t12 = *((int *)t11);
    t8 = (t0 + 1928U);
    t13 = *((char **)t8);
    t14 = *((int *)t13);
    t15 = (t12 - t14);
    t8 = (t0 + 2048U);
    t16 = *((char **)t8);
    t8 = (t16 + 0);
    *((int *)t8) = t15;
    goto LAB3;

LAB7:    xsi_set_current_line(29, ng0);
    t8 = (t0 + 1808U);
    t11 = *((char **)t8);
    t12 = *((int *)t11);
    t8 = (t0 + 1928U);
    t13 = *((char **)t8);
    t14 = *((int *)t13);
    t15 = (t12 * t14);
    t8 = (t0 + 2048U);
    t16 = *((char **)t8);
    t8 = (t16 + 0);
    *((int *)t8) = t15;
    goto LAB3;

LAB9:    xsi_size_not_matching(8U, t9, 0);
    goto LAB10;

}


extern void work_a_1481485318_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1481485318_3212880686_p_0};
	xsi_register_didat("work_a_1481485318_3212880686", "isim/tes1_isim_beh.exe.sim/work/a_1481485318_3212880686.didat");
	xsi_register_executes(pe);
}
